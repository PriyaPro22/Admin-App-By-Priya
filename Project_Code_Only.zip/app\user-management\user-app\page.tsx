"use client";

import PlaceholderPage from "../../components/PlaceholderPage";

export default function UserAppManagement() {
    return <PlaceholderPage title="User App Configuration" />;
}
