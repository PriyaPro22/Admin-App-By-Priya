"use client";

import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import axios from 'axios';
import { api } from '../utils/api';


const BASE_URL = "https://api.bijliwalaaya.in/api/product-listing";
// Define Types
// export interface MainCategory {
//   _id: string;                 
//   name: string;
//   image: string | null;
//   visible: boolean;
//   isSubCategory: boolean;
//   parentCategory?: string | null;
// }
export interface MainCategory {
  _id: string;
  name: string;

  isMainCategoryVisible: boolean;
  isMainCategoryNameVisible: boolean;
  isMainCategoryImageVisible: boolean;

  hasSubCategory: boolean;
  parentId?: string | null;

  imageUri?: string | null;
  imageFile?: File | null;
}

// Sub Category Interface
export interface SubCategory {
  documentId: string;
  name: string;
  mainCategoryId: string;
  visible: boolean;
  isSubCategoryVisible: boolean;
  isSubCategoryNameVisible: boolean; // Added this field
  isSubCategoryImageVisible: boolean;
  imageUri?: string | null;
  hasChild?: boolean;
  hasSubCategory?: boolean;
}

// Child Category Interface
export interface ChildCategory {
  documentId: string;
  name: string;
  subCategoryId?: string;
  imageUri?: string | null;
  isChildCategoryVisible?: boolean;
  visible?: boolean;
}

// Deep Child Category Interface
// Deep Child Category Interface
export interface DeepChildCategory {
  id: string;
  documentId?: string; // Add this if inconsistent
  childCategoryId: string;
  childCategoryName: string; // denormalized

  // Content
  firstTitle: string;
  secondTitle: string;
  description: string;

  // URLs & Media
  webviewUrl?: string;
  imageUri?: string | null;

  // Pricing & Time
  originalPrice?: number;
  discountType?: string; // "%" | "Flat"
  discountValue?: number;
  gst?: number;
  gstType?: string;
  priceAfterGst?: number;
  currentPrice?: number;
  minTime?: number | string;
  maxTime?: number | string;

  // Visibility (Main)
  visible?: boolean;
  deepCategoryVisible?: boolean; // Sometimes used as main visibility

  // Field Visibility Flags
  firstTitleVisible?: boolean;
  secondTitleVisible?: boolean;
  descriptionVisible?: boolean;
  webviewUrlVisible?: boolean;
  originalPriceVisible?: boolean;
  currentPriceVisible?: boolean;
  minTimeVisible?: boolean;
  maxTimeVisible?: boolean;
  photoVisible?: boolean;
  videoVisible?: boolean;

  // Navigation Context (For Updates)
  mainCategoryId?: string;
  subCategoryId?: string | null;
}

// Sub Deep Child Category Interface
export interface SubDeepChildCategory {
  id: string;
  subDeepKey?: string;
  documentId?: string;

  // Navigation
  deepChildCategoryId: string;
  childCategoryId: string; // needed for path
  mainCategoryId?: string; // needed for path
  subCategoryId?: string | null;

  deepChildCategoryName: string;

  // Content
  firstTitle: string;
  secondTitle: string;
  description: string;
  webviewUrl?: string;

  // Visibility
  visible?: boolean; // main toggle usage
  subDeepCategoryVisible?: boolean;

  // Pricing & Time
  originalPrice?: number;
  discountType?: string;
  discountValue?: number;
  gst?: number;
  gstType?: string;
  priceAfterGst?: number;
  currentPrice?: number;
  minTime?: number | string;
  maxTime?: number | string;

  // Field Visibility flags
  firstTitleVisible?: boolean;
  secondTitleVisible?: boolean;
  descriptionVisible?: boolean;
  webviewUrlVisible?: boolean;
  originalPriceVisible?: boolean;
  currentPriceVisible?: boolean;
  minTimeVisible?: boolean;
  maxTimeVisible?: boolean;
  photoVisible?: boolean;
  videoVisible?: boolean;
}

interface CategoryContextType {
  mainCategories: MainCategory[];
  subCategories: SubCategory[];
  childCategories: ChildCategory[];
  deepChildCategories: DeepChildCategory[];
  subDeepChildCategories: SubDeepChildCategory[];

  fetchMainCategories: () => Promise<void>;
  fetchSubCategories: (mainId: string) => Promise<void>;
  fetchChildCategories: (mainId: string, subId: string | null) => Promise<void>;

  // Implementation uses (mainId, childId, subId)
  fetchDeepChildCategories: (mainId: string, childId: string, subId?: string | null) => Promise<void>;

  fetchSubDeepChildCategories: (mainId: string, childId: string, deepId: string, subId?: string | null) => void;

  updateMainCategory: (item: any) => Promise<void>;
  updateSubCategory: (item: any) => Promise<void>;
  updateChildCategory: (item: any) => Promise<void>;
  updateChildCategoryWithSub: (item: any) => Promise<void>;
  updateDeepChildCategory: (item: any) => Promise<void>;
  updateDeepChildCategoryWithSub: (item: any) => Promise<void>;
  updateSubDeepChildCategory: (item: any) => Promise<void>;

  addMainCategory: (category: Omit<MainCategory, 'id'>) => Promise<void>;
  addSubCategory: (category: Omit<SubCategory, 'id'>) => Promise<void>;
  addChildCategory: (category: Omit<ChildCategory, 'id'>) => Promise<void>;
  addDeepChildCategory: (category: Omit<DeepChildCategory, 'id'>) => Promise<void>;
  addSubDeepChildCategory: (category: Omit<SubDeepChildCategory, 'id'>) => void;

  deleteMainCategory: (id: string) => Promise<void>;
  deleteSubCategory: (id: string) => Promise<void>;
  deleteChildCategory: (id: string) => Promise<void>;
  deleteDeepChildCategory: (id: string) => Promise<void>;
  deleteSubDeepChildCategory: (id: string) => void;

  toggleMainVisibility: (id: string) => Promise<void>;
  toggleMainNameVisibility: (id: string) => Promise<void>;
  toggleMainImageVisibility: (id: string) => Promise<void>;
  toggleMainIsSub: (id: string) => Promise<void>;
  toggleSubVisibility: (id: string) => Promise<void>;
  toggleSubNameVisibility: (id: string) => Promise<void>; // Added this
  toggleSubImageVisibility: (id: string) => Promise<void>;
  toggleSubHasSubCategory: (id: string) => Promise<void>;

  toggleChildVisibility: (id: string) => Promise<void>;
  toggleDeepChildVisibility: (id: string, field?: string) => Promise<void>;
  toggleSubDeepChildVisibility: (id: string, field?: string) => void;
  isLoadingSubDeep: boolean;
}

const CategoryContext = createContext<CategoryContextType | undefined>(undefined);

const getAuthHeaders = () => {
  const token = localStorage.getItem("token");
  return {
    "x-api-token": "super_secure_token",
    Authorization: token ? `Bearer ${token}` : "",
    "Content-Type": "multipart/form-data", // Important for FormData
  };
};

export const CategoryProvider = ({ children }: { children: ReactNode }) => {
  const [mainCategories, setMainCategories] = useState<MainCategory[]>([]);
  const [subCategories, setSubCategories] = useState<SubCategory[]>([]);
  const [childCategories, setChildCategories] = useState<ChildCategory[]>([]);
  const [deepChildCategories, setDeepChildCategories] = useState<DeepChildCategory[]>([]);
  const [subDeepChildCategories, setSubDeepChildCategories] = useState<SubDeepChildCategory[]>([]); // Local state for SubDeep
  const [isLoadingSubDeep, setIsLoadingSubDeep] = useState<boolean>(false);


  // FETCH MAIN DATA ON MOUNT
  useEffect(() => {
    fetchMainCategories();
  }, []);

  const fetchMainCategories = async () => {
    try {
      const token = localStorage.getItem("token");
      const response = await axios.get("https://api.bijliwalaaya.in/api/product-listing/main", {
        headers: {
          "Content-Type": "application/json",
          "x-api-token": "super_secure_token",
          Authorization: token ? `Bearer ${token}` : "",
        },
      });

      const data = response.data;
      const rawList =
        Array.isArray(data?.data)
          ? data.data
          : Array.isArray(data?.result)
            ? data.result
            : [];

      // Map to ensure interface compliance
      const list = rawList.map((item: any) => ({
        _id: item.documentId || item._id,
        documentId: item.documentId,
        name: item.name,
        imageUri: item.imageUri || item.image,

        // Normalizing visibility
        isMainCategoryVisible: item.isMainCategoryVisible ?? item.visible ?? true,
        isMainCategoryNameVisible: item.isMainCategoryNameVisible ?? true,
        isMainCategoryImageVisible: item.isMainCategoryImageVisible ?? true,

        // Normalizing sub-category flag
        hasSubCategory: item.hasSubCategory ?? item.isSubCategory ?? false,
        parentId: item.parentId,

      }));

      console.log("🔥 MAIN CATEGORY LIST:", list);

      setMainCategories(list);

    } catch (error: any) {
      console.error(
        "Failed to fetch main categories:",
        error?.response?.status,
        error?.response?.data
      );
      // alert("Failed to fetch main categories."); 
    }
  };

  // const updateMainCategory = async (item: any) => {
  //   try {
  //     const token = localStorage.getItem("token");

  //     // ✅ SAME FIELDS JO FETCH ME USE HO RAHE HAIN
  //     const payload = {
  //       name: item.name,
  //       imageUri: item.imageUri || null,

  //       // visibility fields
  //       isMainCategoryVisible: item.isMainCategoryVisible,
  //       isMainCategoryNameVisible: item.isMainCategoryNameVisible,
  //       isMainCategoryImageVisible: item.isMainCategoryImageVisible,

  //       // sub-category flag
  //       hasSubCategory: item.hasSubCategory,

  //       // optional
  //       parentId: item.parentId || null,
  //     };

  //     console.log("📦 MAIN UPDATE PAYLOAD:", payload);

  //     await axios.put(
  //       `https://api.bijliwalaaya.in/api/product-listing/main/${item._id}`,
  //       payload,
  //       {
  //         headers: {
  //           "Content-Type": "application/json",
  //           "x-api-token": "super_secure_token",
  //           Authorization: token ? `Bearer ${token}` : "",
  //         },
  //       }
  //     );

  //     // 🔥 REFRESH UI FROM MONGO
  //     await fetchMainCategories();

  //     console.log("✅ Main category updated successfully");

  //   } catch (error: any) {
  //     console.error(
  //       "❌ Failed to update main category:",
  //       error?.response?.status,
  //       error?.response?.data || error.message
  //     );
  //   }
  // };



  // Helper to fetch subs for a main
  // =======================
  // 🔥 FETCH SUB CATEGORIES (FINAL & CORRECT)
  // =======================

  const updateMainCategory = async (item: any) => {
    const token = localStorage.getItem("token");

    const formData = new FormData();
    formData.append("name", item.name);

    // Boolean fields need string conversion for FormData
    formData.append("isMainCategoryVisible", String(item.isMainCategoryVisible));
    formData.append("isMainCategoryNameVisible", String(item.isMainCategoryNameVisible));
    formData.append("isMainCategoryImageVisible", String(item.isMainCategoryImageVisible));
    formData.append("hasSubCategory", String(item.hasSubCategory));

    if (item.parentId) {
      formData.append("parentId", item.parentId);
    }

    // Only append image if it's a new file (File object)
    if (item.imageFile instanceof File) {
      formData.append("imageUri", item.imageFile);
    }

    try {
      await axios.put(
        `https://api.bijliwalaaya.in/api/product-listing/main/${item._id}`,
        formData,
        {
          headers: {
            "x-api-token": "super_secure_token",
            Authorization: token ? `Bearer ${token}` : "",
          },
        }
      );

      await fetchMainCategories();
    } catch (error: any) {
      console.error(
        "❌ Failed to update main category:",
        error?.response?.status,
        error?.response?.data || error.message
      );
      throw error; // Propagate error so form knows it failed
    }
  };
  const updateSubCategory = async (item: any) => {
    const formData = new FormData();

    formData.append("name", item.name);
    formData.append("mainCategory", item.mainCategoryId);

    formData.append("isSubCategoryVisible", String(item.isSubCategoryVisible));
    formData.append("isSubCategoryNameVisible", String(item.isSubCategoryNameVisible));
    formData.append("isSubCategoryImageVisible", String(item.isSubCategoryImageVisible));

    if (item.imageFile instanceof File) {
      formData.append("imageUri", item.imageFile);
    }

    try {
      await axios.put(
        `https://api.bijliwalaaya.in/api/product-listing/main/${item.mainCategoryId}/sub/${item.documentId}`,
        formData,
        { headers: getAuthHeaders() }
      );
    } catch (err) {
      console.error("❌ Failed to update sub category", err);
      throw err;
    }
  };
  const updateChildCategory = async (item: any) => {
    const formData = new FormData();

    formData.append("name", item.name);
    formData.append("visibility", String(item.visible));

    if (item.imageFile instanceof File) {
      formData.append("imageUri", item.imageFile);
    }

    try {
      await axios.put(
        `https://api.bijliwalaaya.in/api/product-listing/main/${item.mainCategoryId}/child/${item.documentId}`,
        formData,
        { headers: getAuthHeaders() }
      );
    } catch (err) {
      console.error("❌ Failed to update child category", err);
      throw err;
    }
  };
  const updateChildCategoryWithSub = async (item: any) => {
    const formData = new FormData();

    formData.append("name", item.name);
    formData.append("visibility", String(item.visible));

    if (item.imageFile instanceof File) {
      formData.append("imageUri", item.imageFile);
    }

    try {
      await axios.put(
        `https://api.bijliwalaaya.in/api/product-listing/main/${item.mainCategoryId}/sub/${item.subCategoryId}/child/${item.documentId}`,
        formData,
        { headers: getAuthHeaders() }
      );
    } catch (err) {
      console.error("❌ Failed to update child category (sub)", err);
      throw err;
    }
  };
  const updateDeepChildCategory = async (item: any) => {
    const formData = new FormData();

    formData.append("documentId", item.documentId);
    formData.append("firstTitle", item.firstTitle);
    formData.append("secondTitle", item.secondTitle);
    formData.append("description", item.description);

    formData.append("deepCategoryVisible", String(item.deepCategoryVisible));

    formData.append("firstTitleVisible", String(item.firstTitleVisible));
    formData.append("secondTitleVisible", String(item.secondTitleVisible));
    formData.append("descriptionVisible", String(item.descriptionVisible));

    formData.append("originalPrice", String(item.originalPrice ?? ""));
    formData.append("currentPrice", String(item.currentPrice ?? ""));
    formData.append("priceAfterGst", String(item.priceAfterGst ?? ""));

    if (item.imageFile instanceof File) {
      formData.append("imageUri", item.imageFile);
    }

    try {
      await axios.put(
        `https://api.bijliwalaaya.in/api/product-listing/main/${item.mainCategoryId}/child/${item.childCategoryId}/deep/${item.documentId}`,
        formData,
        { headers: getAuthHeaders() }
      );
    } catch (err) {
      console.error("❌ Failed to update deep child", err);
      throw err;
    }
  };
  const updateDeepChildCategoryWithSub = async (item: any) => {
    const formData = new FormData();

    formData.append("documentId", item.documentId);
    formData.append("firstTitle", item.firstTitle);
    formData.append("secondTitle", item.secondTitle);
    formData.append("description", item.description);

    formData.append("deepCategoryVisible", String(item.deepCategoryVisible));

    if (item.imageFile instanceof File) {
      formData.append("imageUri", item.imageFile);
    }

    try {
      await axios.put(
        `https://api.bijliwalaaya.in/api/product-listing/main/${item.mainCategoryId}/sub/${item.subCategoryId}/child/${item.childCategoryId}/deep/${item.documentId}`,
        formData,
        { headers: getAuthHeaders() }
      );
    } catch (err) {
      console.error("❌ Failed to update deep child (sub)", err);
      throw err;
    }
  };
  const updateSubDeepChildCategory = async (item: any) => {
    const formData = new FormData();

    formData.append("documentId", item.documentId);
    formData.append("firstTitle", item.firstTitle);
    formData.append("secondTitle", item.secondTitle);
    formData.append("description", item.description);

    formData.append("subDeepCategoryVisible", String(item.subDeepCategoryVisible));

    if (item.imageFile instanceof File) {
      formData.append("imageUri", item.imageFile);
    }

    const baseUrl = item.subCategoryId
      ? `https://api.bijliwalaaya.in/api/product-listing/main/${item.mainCategoryId}/sub/${item.subCategoryId}/child/${item.childCategoryId}/deep/${item.deepChildCategoryId}/sub/${item.documentId}`
      : `https://api.bijliwalaaya.in/api/product-listing/main/${item.mainCategoryId}/child/${item.childCategoryId}/deep/${item.deepChildCategoryId}/sub/${item.documentId}`;

    try {
      await axios.put(baseUrl, formData, {
        headers: getAuthHeaders(),
      });
    } catch (err) {
      console.error("❌ Failed to update sub-deep child", err);
      throw err;
    }
  };



  const fetchSubCategories = async (mainId: string) => {
    try {
      const token = localStorage.getItem("token");

      const res = await axios.get(
        `https://api.bijliwalaaya.in/api/product-listing/main/${mainId}/sub`,
        {
          headers: {
            Authorization: token ? `Bearer ${token}` : "",
            "x-api-token": "super_secure_token",
          },
        }
      );

      // Robust data extraction
      let raw = res.data?.data;
      if (!raw && Array.isArray(res.data?.result)) raw = res.data?.result;
      if (!raw && (Array.isArray(res.data) || typeof res.data === 'object')) raw = res.data;
      if (!raw) raw = {};

      console.log("🔥 FETCH SUB RAW:", raw);

      let subs: any[] = [];

      // Find parent name
      const parentName = mainCategories.find(m => m._id === mainId)?.name || "Root";

      if (Array.isArray(raw)) {
        subs = raw.map((item: any) => ({
          documentId: item.documentId || item._id || item.id,
          name: item.name,
          imageUri: item.imageUri || item.image,
          visible: item.visible ?? item.isSubCategoryVisible ?? true,
          hasChild: true,
          hasSubCategory: true,
          mainCategoryId: mainId,
          parentName: parentName, // Add explicit parent name
          isSubCategoryVisible: item.isSubCategoryVisible ?? item.visible ?? true,
          isSubCategoryNameVisible: item.isSubCategoryNameVisible ?? true, // Default to true
          isSubCategoryImageVisible: item.isSubCategoryImageVisible ?? true,
        }));
      } else {
        // Object entries map - IMPORTANT: 'raw' is object with keys as IDs
        subs = Object.entries(raw).map(([key, value]: any) => ({
          documentId: key,
          name: value.name,
          imageUri: value.imageUri || value.image,
          visible: value.visible ?? value.isSubCategoryVisible ?? true,
          hasChild: true,
          hasSubCategory: value.hasSubCategory ?? value.isSubCategory ?? true,
          mainCategoryId: mainId,
          rawChild: value,
          parentName: parentName,
          isSubCategoryVisible: value.isSubCategoryVisible ?? value.visible ?? true,
          isSubCategoryNameVisible: value.isSubCategoryNameVisible ?? true, // Default to true
          isSubCategoryImageVisible: value.isSubCategoryImageVisible ?? true,
        }));
      }

      setSubCategories(subs);



    } catch (err) {
      console.error("❌ Error fetching sub categories:", err);
      setSubCategories([]);
      setChildCategories([]);
    }
  };





  // subCategories






  // Helper for children
  const fetchChildCategories = async (
    mainId: string,
    subId?: string | null
  ) => {
    setChildCategories([]);
    try {
      if (!mainId) {
        console.warn("❗ mainId missing");
        setChildCategories([]);
        return;
      }

      const token = localStorage.getItem("token");

      const url = subId
        ? `https://api.bijliwalaaya.in/api/product-listing/main/${mainId}/sub/${subId}/child`
        : `https://api.bijliwalaaya.in/api/product-listing/main/${mainId}/child`;

      console.log("🚀 CHILD CATEGORY URL:", url);

      const response = await axios.get(url, {
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
          "x-api-token": "super_secure_token",
          "Content-Type": "application/json",
        },
      });

      console.log("🔥 RAW CHILD CATEGORY RESPONSE:", response.data);

      /**
       * ✅ BACKEND RESPONSE FORMAT
       * {
       *   success: true,
       *   data: {
       *     childId1: {...},
       *     childId2: {...}
       *   }
       * }
       */

      const rawData = response.data?.data || {};

      // Determine parent name
      let parentName = "Root";
      if (subId) {
        parentName = subCategories.find(s => (s.documentId || (s as any)._id) === subId)?.name || "Sub Category";
      } else {
        parentName = mainCategories.find(m => m._id === mainId)?.name || "Main Category";
      }

      // ✅ OBJECT → ARRAY CONVERSION (IMPORTANT FIX)
      const list = Array.isArray(rawData)
        ? rawData.map((item: any) => ({ ...item, parentName }))
        : Object.entries(rawData).map(([id, value]: any) => ({
          documentId: id,
          ...value,
          parentName
        }));

      console.log("✅ FINAL CHILD CATEGORY LIST:", list);

      setChildCategories(list);
    } catch (error: any) {
      console.error(
        "❌ Error fetching child categories:",
        error?.response?.status,
        error?.response?.data || error.message
      );
      setChildCategories([]);
    }
  };



  // Helper for deep children
  const fetchDeepChildCategories = async (
    mainId: string,
    childId: string,
    subId?: string | null
  ) => {
    setDeepChildCategories([]);
    try {
      if (!mainId || !childId) {
        console.error("❌ Missing IDs for Deep Fetch:", { mainId, childId });
        return;
      }

      let url = "";

      // 🔥 CASE 1: WITH SUB CATEGORY
      if (subId) {
        url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainId}/sub/${subId}/child/${childId}/deep`;
      }
      // 🔥 CASE 2: WITHOUT SUB CATEGORY
      else {
        url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainId}/child/${childId}/deep`;
      }

      console.log("🚀 FETCH DEEP URL:", url);

      const res = await api.get(url);
      console.log("🔥 FULL API RESPONSE:", res); // Debug full response
      const rawData = res.data?.data || {};
      console.log("🔥 RAW DATA FROM API:", rawData); // Debug raw data

      // 🔥 OBJECT → ARRAY FIX & INJECT PARENT IDs
      const list = (Array.isArray(rawData)
        ? rawData
        : Object.entries(rawData).map(([id, value]: any) => ({
          documentId: id,
          ...value,
        }))).map((item: any) => ({
          ...item,
          mainCategoryId: mainId,
          childCategoryId: childId,
          subCategoryId: subId
        }));

      console.log("✅ FINAL DEEP CHILD LIST (Set to State):", list);

      setDeepChildCategories(list);
    } catch (error: any) {
      console.error("❌ Error fetching deep child categories:", error);
      setDeepChildCategories([]);
    }
  };
  /* ===============================
      FETCH SUB DEEP CHILD CATEGORIES (FIXED)
  =============================== */

  const fetchSubDeepChildCategories = async (
    mainId: string,
    childKey: string,
    deepKey: string,
    subId?: string | null
  ) => {
    try {
      if (!mainId || !childKey || !deepKey) {
        console.error("❌ Missing keys for Sub Deep Fetch:", { mainId, childKey, deepKey });
        return [];
      }

      setIsLoadingSubDeep(true); // START LOADING
      let url = "";

      // Ensure subId is a valid non-empty string
      if (subId && typeof subId === 'string' && subId.trim() !== "") {
        url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainId}/sub/${subId}/child/${childKey}/deep/${deepKey}/sub`;
      } else {
        url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainId}/child/${childKey}/deep/${deepKey}/sub`;
      }

      console.log("🚀 FETCH SUB-DEEP URL:", url);

      const res = await api.get(url);

      // Detailed Debugging
      console.log("🧪 SUB-DEEP RESPONSE STATUS:", res.status);
      try {
        console.log("🧪 SUB-DEEP RESPONSE BODY:", JSON.stringify(res.data, null, 2));
      } catch (e) { console.log("🧪 SUB-DEEP RESPONSE BODY (Unstringifyable):", res.data); }


      // Helper to find the payload
      const findPayload = (obj: any): any => {
        if (!obj) return [];

        // 1. Direct Array
        if (Array.isArray(obj)) return obj;

        // 2. Known Wrapper Keys (Prioritized)
        // Check for plural/singular specific keys
        if (obj.subDeepChildCategories && typeof obj.subDeepChildCategories === 'object') {
          return findPayload(obj.subDeepChildCategories); // Recurse to handle if it's an array or map
        }
        if (obj.subDeepChildCategory && typeof obj.subDeepChildCategory === 'object') {
          return findPayload(obj.subDeepChildCategory);
        }

        // 3. Generic Data Keys (Only if they contain substantial data)
        if (obj.data && typeof obj.data === 'object' && Object.keys(obj.data).length > 0) {
          return findPayload(obj.data);
        }
        if (obj.result && typeof obj.result === 'object' && Object.keys(obj.result).length > 0) {
          return findPayload(obj.result);
        }

        // 4. Fallback: Assume the object itself is the map if it has keys that aren't metadata
        const keys = Object.keys(obj);
        const isMetadata = (k: string) => ["success", "message", "status", "count", "docId"].includes(k);
        const hasDataKeys = keys.some(k => !isMetadata(k));

        if (hasDataKeys) {
          // Return object without metadata
          const { success, message, status, count, docId, ...rest } = obj;
          return rest;
        }

        return [];
      };

      let rawData = findPayload(res.data);
      console.log("🧪 EXTRACTED RAW DATA:", { type: Array.isArray(rawData) ? 'Array' : typeof rawData, keys: Object.keys(rawData || {}) });

      // Final processing
      let list: any[] = [];

      // Helper to flatten item data
      const flattenItem = (item: any) => {
        if (!item) return {};
        // Prioritize detailedData, then data, then the item itself
        const core = item.detailedData || item.data || item;
        // Ensure we keep the ID and external keys if core was nested
        return { ...item, ...core };
      };

      if (Array.isArray(rawData)) {
        list = rawData.map((rawItem: any) => {
          const item = flattenItem(rawItem);
          return {
            ...item,
            id: item.documentId || item._id || item.id,
            subDeepKey: item.documentId || item._id || item.id,
            mainCategoryId: mainId,
            childCategoryId: childKey,
            deepChildCategoryId: deepKey,
            subCategoryId: subId || null,
            subDeepCategoryVisible: item.subDeepCategoryVisible ?? item.visible ?? false
          }
        });
      } else if (typeof rawData === 'object' && rawData !== null) {
        list = Object.entries(rawData).map(([key, value]: any) => {
          if (typeof value !== 'object' || value === null) return null;
          const item = flattenItem(value);
          return {
            id: key,
            documentId: key,
            subDeepKey: key,
            ...item,
            mainCategoryId: mainId,
            childCategoryId: childKey,
            deepChildCategoryId: deepKey,
            subCategoryId: subId || null,
            subDeepCategoryVisible: item.subDeepCategoryVisible ?? item.visible ?? false
          };
        }).filter(item => item !== null);
      }

      console.log(`✅ FINAL SUB-DEEP LIST (${list.length} Items):`, list);

      setSubDeepChildCategories(list);
      setIsLoadingSubDeep(false); // STOP LOADING
      return list;

    } catch (error: any) {
      console.error("❌ Error fetching sub deep child:", error?.message || error);
      setSubDeepChildCategories([]);
      setIsLoadingSubDeep(false); // STOP LOADING
      return [];
    }
  };




  const addMainCategory = async (category: any) => {
    try {
      // Check if duplicate exists (safely) : Trim ensures "Name " == "Name"
      const normalize = (str: string) => (str || "").trim().toLowerCase();
      if (mainCategories.some(c => normalize(c.name) === normalize(category.name))) {
        alert("Main Category with this name already exists!");
        return; // Stop execution
      }

      // 🔒 OPTIMISTIC UPDATE
      const tempId = `temp-${Date.now()}`;
      const tempItem: any = {
        _id: tempId,
        id: tempId,
        name: category.name,
        hasSubCategory: category.hasSubCategory,
        isMainCategoryVisible: category.isMainCategoryVisible,
        imageUri: category.imageFile ? "uploading..." : null,
      };

      setMainCategories(prev => [...prev, tempItem]);

      const token = localStorage.getItem("token");

      const formData = new FormData();

      formData.append("_id", category._id);
      formData.append("documentId", category._id);
      formData.append("name", category.name);
      formData.append("parentId", category.parentId || "");
      formData.append("hasSubCategory", String(category.hasSubCategory));
      formData.append("isMainCategoryVisible", String(category.isMainCategoryVisible));
      formData.append("isMainCategoryNameVisible", String(category.isMainCategoryNameVisible ?? true));
      formData.append(
        "isMainCategoryImageVisible",
        String(category.isMainCategoryImageVisible)
      );

      if (category.imageFile) {
        formData.append("imageUri", category.imageFile); // 🔥 multer field
      }

      const res = await axios.post(
        "https://api.bijliwalaaya.in/api/product-listing/main",
        formData,
        {
          headers: {
            Authorization: token ? `Bearer ${token}` : "",
            "x-api-token": "super_secure_token",
            // ❌ Content-Type MAT LIKHO
          },
        }
      );

      await fetchMainCategories();
      return res.data;
    } catch (error: any) {
      console.error(
        "❌ ADD MAIN CATEGORY ERROR:",
        error?.response?.status,
        error?.response?.data || error.message
      );
      // 🔙 Revert on error - remove safe check as tempId is unique
      setMainCategories(prev => prev.filter(item => !(item._id || "").startsWith("temp-")));
      throw error;
    }
  };


  // const addSubCategory = async (category: {
  //   _id: string;              // subCategoryId
  //   name: string;
  //   mainCategoryId: string;   // mainCategoryId
  //   visible: boolean;
  //   imageUri?: string | null;
  // }) => {
  //   try {
  //     const token = localStorage.getItem("token");

  //     const payloadSubcat = {
  //       documentId: category._id,
  //       name: category.name,

  //       mainCategory: category.mainCategoryId, // ✅ VERY IMPORTANT

  //       isSubCategoryVisible: category.visible,
  //       isSubCategoryNameVisible: true,
  //       isSubCategoryImageVisible: true,

  //       imageUri: category.imageUri || null,
  //     };


  //     // 🔥 DEBUG (VERY IMPORTANT)
  //     console.log(
  //       "🚀 FINAL URL:",
  //       `https://api.bijliwalaaya.in/api/product-listing/main/${payloadSubcat.mainCategory}/sub/${payloadSubcat.documentId}`
  //     );
  //     console.log("📦 PAYLOAD:", payloadSubcat);

  //     const res = await axios.post(
  //       `https://api.bijliwalaaya.in/api/product-listing/main/${payloadSubcat.mainCategory}/sub/${payloadSubcat.documentId}`,
  //       payloadSubcat,
  //       {
  //         headers: {
  //           Authorization: token ? `Bearer ${token}` : "",
  //           "x-api-token": "super_secure_token",
  //           "Content-Type": "application/json",
  //         },
  //       }
  //     );

  //     return res.data;
  //   } catch (error: any) {
  //     console.error(
  //       "❌ SubCategory Error:",
  //       error.response?.data || error.message
  //     );
  //     throw new Error("Failed to save sub category");
  //   }
  // };
  // const addChildCategory = async (category: {
  //   name: string;
  //   mainCategoryId: string;
  //   subCategoryId?: string | null;
  //   visible: boolean;
  // }) => {
  //   try {
  //     const token = localStorage.getItem("token");


  //     const childId = category.name; 

  //     const url = category.subCategoryId
  //       ? `https://api.bijliwalaaya.in/api/product-listing/main/${category.mainCategoryId}/sub/${category.subCategoryId}/child/${childId}`
  //       : `https://api.bijliwalaaya.in/api/product-listing/main/${category.mainCategoryId}/child/${childId}`;

  //     const payload = {
  //       name: category.name,
  //       Visibility: true, 
  //     };

  //     console.log("🚀 CHILD CATEGORY URL:", url);
  //     console.log("📦 PAYLOAD:", payload);

  //     await axios.post(url, payload, {
  //       headers: {
  //         Authorization: token ? `Bearer ${token}` : "",
  //         "x-api-token": "super_secure_token",
  //         "Content-Type": "application/json",
  //       },
  //     });
  //   } catch (error: any) {
  //     console.error("❌ Failed to add child category:", error);
  //     throw new Error("Failed to add child category");
  //   }
  // };
  // const addDeepChildCategory = async (data: any) => {
  //   const token = localStorage.getItem("token");

  //   const mainCategoryId = data.mainCategoryId;
  //   const subCategoryId = data.subCategoryId || null;
  //   const childCategoryId = data.childCategoryId;
  //   const deepId = data.deepChildId; // 🔥 URL PARAM

  //   if (!mainCategoryId || !childCategoryId || !deepId) {
  //     console.error("❌ MAIN / CHILD / DEEP ID MISSING");
  //     return;
  //   }

  //   let url = "";

  //   // ✅ WITH SUB CATEGORY
  //   if (subCategoryId) {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/sub/${subCategoryId}/child/${childCategoryId}/deep/${deepId}`;
  //   }
  //   // ✅ WITHOUT SUB CATEGORY
  //   else {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/child/${childCategoryId}/deep/${deepId}`;
  //   }

  //   console.log("🌐 FINAL POST URL:", url);

  //   return axios.post(
  //     url,
  //     {
  //       firstTitle: data.firstTitle,
  //       secondTitle: data.secondTitle,
  //       description: data.description,
  //       visible: data.visible,
  //       webviewUrl: data.webviewUrl,

  //       originalPrice: data.originalPrice,
  //       discountType: data.discountType,
  //       discountValue: data.discountValue,
  //       gst: data.gst,
  //       gstType: data.gstType,
  //       minTime: data.minTime,
  //       maxTime: data.maxTime,
  //       finalPrice: data.finalPrice,
  //       totalPrice: data.totalPrice,

  //       firstTitleVisible: data.firstTitleVisible,
  //       secondTitleVisible: data.secondTitleVisible,
  //       descriptionVisible: data.descriptionVisible,
  //       webviewUrlVisible: data.webviewUrlVisible,
  //       originalPriceVisible: data.originalPriceVisible,
  //       minTimeVisible: data.minTimeVisible,
  //       maxTimeVisible: data.maxTimeVisible,

  //       photoVisible: data.photoVisible,
  //       videoVisible: data.videoVisible,
  //     },
  //     {
  //       headers: {
  //         Authorization: token ? `Bearer ${token}` : "",
  //         "x-api-token": "super_secure_token",
  //         "Content-Type": "application/json",
  //       },
  //     }
  //   );
  // };



  const addSubCategory = async (category: any) => {
    // Check if duplicate exists (safely) within the SAME Main Category
    const normalize = (str: string) => (str || "").trim().toLowerCase();

    // We check if name matches AND mainCategoryId matches
    // Since 'subCategories' usually contains the list for the ACTIVE main category, 
    // we should validly check against it.
    // However, to be absolutely safe against state having mixed items:
    const isDuplicate = subCategories.some(c =>
      normalize(c.name) === normalize(category.name) &&
      (c.mainCategoryId === category.mainCategoryId || (c as any).mainCategory === category.mainCategoryId)
    );

    if (isDuplicate) {
      alert("Sub Category with this name already exists in this Main Category!");
      return;
    }

    const token = localStorage.getItem("token");
    const formData = new FormData();

    formData.append("documentId", category._id);
    formData.append("name", category.name);
    formData.append("mainCategory", category.mainCategoryId);
    formData.append("isSubCategoryVisible", String(category.visible));
    formData.append("isSubCategoryNameVisible", "true");
    formData.append("isSubCategoryImageVisible", "true");

    // ✅ multer expects "image"
    if (category.imageFile) {
      formData.append("imageUri", category.imageFile); // 🔥 THIS WILL APPEAR NOW
    }

    console.log("📦 FORM DATA:", [...formData.entries()]);

    const res = await axios.post(
      `https://api.bijliwalaaya.in/api/product-listing/main/${category.mainCategoryId}/sub/${category._id}`,
      formData,
      {
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
          "x-api-token": "super_secure_token",
        },
      }
    );

    await fetchSubCategories(category.mainCategoryId);
    return res.data;
  };

  const addChildCategory = async (category: {
    name: string;
    mainCategoryId: string;
    subCategoryId?: string | null;
    visible: boolean;
  }) => {
    // Check if duplicate exists (safely)
    const normalize = (str: string) => (str || "").trim().toLowerCase();
    if (childCategories.some(c => normalize(c.name) === normalize(category.name))) {
      alert("Child Category with this name already exists!");
      return;
    }

    // 🔒 OPTIMISTIC UPDATE
    const tempId = `temp-${Date.now()}`;
    const tempItem: any = {
      _id: tempId,
      documentId: tempId,
      name: category.name,
      visible: category.visible,
      subCategoryId: category.subCategoryId,
      mainCategoryId: category.mainCategoryId,
      isChildCategoryVisible: true
    };

    setChildCategories(prev => [...prev, tempItem]);

    try {
      const token = localStorage.getItem("token");

      // ✅ URL SAFE ID
      const childId = encodeURIComponent(category.name);

      const url = category.subCategoryId
        ? `https://api.bijliwalaaya.in/api/product-listing/main/${category.mainCategoryId}/sub/${category.subCategoryId}/child/${childId}`
        : `https://api.bijliwalaaya.in/api/product-listing/main/${category.mainCategoryId}/child/${childId}`;

      // ✅ FIXED PAYLOAD
      const payload = {
        name: category.name,
        visibility: true, // ✅ lowercase (VERY IMPORTANT)
      };

      console.log("🚀 CHILD CATEGORY URL:", url);
      console.log("📦 PAYLOAD:", payload);

      await axios.post(url, payload, {
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
          "x-api-token": "super_secure_token",
          "Content-Type": "application/json",
        },
      });

      await fetchChildCategories(category.mainCategoryId, category.subCategoryId);
    } catch (error: any) {
      // 🔙 REVERT
      setChildCategories(prev => prev.filter(item => item.documentId !== tempId));

      console.error("❌ Failed to add child category:", error?.response?.data || error);
      throw new Error("Failed to add child category");
    }
  };






  // const addDeepChildCategory = async (data: any) => {
  //   const token = localStorage.getItem("token");

  //   const {
  //     mainCategoryId,
  //     subCategoryId,
  //     childCategoryId,
  //     deepChildId,
  //   } = data;

  //   if (!mainCategoryId || !childCategoryId || !deepChildId) {
  //     console.error("❌ MAIN / CHILD / DEEP ID MISSING");
  //     return;
  //   }

  //   let url = "";

  //   // ✅ WITH SUB CATEGORY
  //   if (subCategoryId) {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/sub/${subCategoryId}/child/${childCategoryId}/deep/${deepChildId}`;
  //   } 
  //   // ✅ WITHOUT SUB CATEGORY
  //   else {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/child/${childCategoryId}/deep/${deepChildId}`;
  //   }

  //   console.log("🌐 FINAL POST URL:", url);

  //   const payload = {
  //     // 📝 CONTENT
  //     firstTitle: data.firstTitle,
  //     secondTitle: data.secondTitle,
  //     description: data.description,
  //     visible: data.visible,
  //     webviewUrl: data.webviewUrl,

  //     // 💰 RAW PRICING
  //     originalPrice: data.originalPrice,
  //     discountType: data.discountType,
  //     discountValue: data.discountValue,
  //     gst: data.gst,
  //     gstType: data.gstType,

  //     // 🔥 CALCULATED (NO UI FIELD)
  //     currentPrice: data.currentPrice,      // after discount
  //     priceAfterGst: data.priceAfterGst,    // final payable
  //     currentPriceVisible: true,

  //     // 👁️ VISIBILITY FLAGS
  //     firstTitleVisible: data.firstTitleVisible,
  //     secondTitleVisible: data.secondTitleVisible,
  //     descriptionVisible: data.descriptionVisible,
  //     webviewUrlVisible: data.webviewUrlVisible,
  //     originalPriceVisible: data.originalPriceVisible,
  //     minTimeVisible: data.minTimeVisible,
  //     maxTimeVisible: data.maxTimeVisible,

  //     // 📷 MEDIA
  //     photoVisible: data.photoVisible,
  //     videoVisible: data.videoVisible,
  //   };

  //   console.log("📦 FINAL DATA GOING TO MONGO:", payload);

  //   return axios.post(
  //     url,
  //     payload,
  //     {
  //       headers: {
  //         Authorization: token ? `Bearer ${token}` : "",
  //         "x-api-token": "super_secure_token",
  //         "Content-Type": "application/json",
  //       },
  //     }
  //   );
  // };

  // const addSubDeepChildCategory = async (data: any) => {
  //   const token = localStorage.getItem("token");

  //   const {
  //     mainCategoryId,
  //     subCategoryId,
  //     childCategoryId,
  //     deepChildCategoryId,
  //     subDeepKey,
  //   } = data;

  //   if (!mainCategoryId || !childCategoryId || !deepChildCategoryId || !subDeepKey) {
  //     console.error("❌ REQUIRED IDS MISSING", {
  //       mainCategoryId,
  //       childCategoryId,
  //       deepChildCategoryId,
  //       subDeepKey,
  //     });
  //     return;
  //   }

  //   let url = "";

  //   // ✅ WITH SUB CATEGORY
  //   if (subCategoryId) {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/sub/${subCategoryId}/child/${childCategoryId}/deep/${deepChildCategoryId}/sub/${subDeepKey}`;
  //   }
  //   // ✅ WITHOUT SUB CATEGORY
  //   else {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/child-key/${childCategoryId}/deep/${deepChildCategoryId}/sub/${subDeepKey}`;
  //   }

  //   console.log("🌐 SUB-DEEP POST URL:", url);
  //   console.log("📦 FINAL DATA GOING TO MONGO:", data);

  //   return axios.post(
  //     url,
  //     {
  //       // 📝 CONTENT
  //       firstTitle: data.firstTitle,
  //       secondTitle: data.secondTitle,
  //       description: data.description,
  //       visible: data.visible,
  //       webviewUrl: data.webviewUrl,

  //       // 💰 PRICING
  //       originalPrice: data.originalPrice,
  //       discountType: data.discountType,
  //       discountValue: data.discountValue,
  //       gst: data.gst,
  //       gstType: data.gstType,
  //       minTime: data.minTime,
  //       maxTime: data.maxTime,
  //       finalPrice: data.finalPrice,
  //       totalPrice: data.totalPrice,

  //       // 👁️ VISIBILITY FLAGS
  //       firstTitleVisible: data.firstTitleVisible,
  //       secondTitleVisible: data.secondTitleVisible,
  //       descriptionVisible: data.descriptionVisible,
  //       webviewUrlVisible: data.webviewUrlVisible,
  //       originalPriceVisible: data.originalPriceVisible,
  //       minTimeVisible: true,
  //       maxTimeVisible: true,

  //       // 📷 MEDIA FLAGS
  //       photoVisible: data.photoVisible,
  //       videoVisible: data.videoVisible,

  //       // 🆔 IDS (Mongo me dikh rahe the images me)
  //       documentId: subDeepKey,
  //       localId: subDeepKey,
  //     },
  //     {
  //       headers: {
  //         Authorization: token ? `Bearer ${token}` : "",
  //         "x-api-token": "super_secure_token",
  //         "Content-Type": "application/json",
  //       },
  //     }
  //   );
  // };
  // const addDeepChildCategory = async (data: any) => {
  //   const token = localStorage.getItem("token");

  //   const {
  //     mainCategoryId,
  //     subCategoryId,
  //     childCategoryId,
  //     deepChildId,
  //   } = data;

  //   if (!mainCategoryId || !childCategoryId || !deepChildId) {
  //     console.error("❌ MAIN / CHILD / DEEP ID MISSING");
  //     return;
  //   }

  //   let url = "";

  //   if (subCategoryId) {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/sub/${subCategoryId}/child/${childCategoryId}/deep/${deepChildId}`;
  //   } else {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/child/${childCategoryId}/deep/${deepChildId}`;
  //   }

  //   // ✅ ✅ ✅ FINAL PAYLOAD (YAHIN ADD KARNA HAI)
  //   const payload = {
  //     documentId: deepChildId, // 🔥 MOST IMPORTANT LINE

  //     // 📝 CONTENT
  //     firstTitle: data.firstTitle,
  //     secondTitle: data.secondTitle,
  //     description: data.description,
  //     visible: data.deepCategoryVisible,
  //     webviewUrl: data.webviewUrl,

  //     // 💰 PRICING
  //     originalPrice: data.originalPrice,
  //     discountType: data.discountType,
  //     discountValue: data.discountValue,
  //     gst: data.gst,
  //     gstType: data.gstType,

  //     currentPrice: data.currentPrice,
  //     priceAfterGst: data.priceAfterGst,
  //     currentPriceVisible: true,

  //     // 👁️ VISIBILITY
  //     firstTitleVisible: data.firstTitleVisible,
  //     secondTitleVisible: data.secondTitleVisible,
  //     descriptionVisible: data.descriptionVisible,
  //     webviewUrlVisible: data.webviewUrlVisible,
  //     originalPriceVisible: data.originalPriceVisible,
  //     minTimeVisible: data.minTimeVisible,
  //     maxTimeVisible: data.maxTimeVisible,

  //     photoVisible: data.photoVisible,
  //     videoVisible: data.videoVisible,
  //   };

  //   console.log("📦 FINAL PAYLOAD WITH DOCUMENT ID:", payload);

  //   return axios.post(url, payload, {
  //     headers: {
  //       Authorization: token ? `Bearer ${token}` : "",
  //       "x-api-token": "super_secure_token",
  //       "Content-Type": "application/json",
  //     },
  //   });
  // };

  const addDeepChildCategory = async (data: any) => {
    const token = localStorage.getItem("token");

    const {
      mainCategoryId,
      subCategoryId,
      childCategoryId,
      deepChildId,
    } = data;

    if (!mainCategoryId || !childCategoryId || !deepChildId) {
      console.error("❌ MAIN / CHILD / DEEP ID MISSING");
      return;
    }

    // Check for duplicate
    // Assuming deepChildId is the "name" or key we want to be unique in this list
    if (deepChildCategories.some(c => (c.id || c.documentId || "").toLowerCase() === deepChildId.toLowerCase())) {
      alert("Deep Child Category with this name/ID already exists!");
      return;
    }

    let url = "";

    if (subCategoryId) {
      url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/sub/${subCategoryId}/child/${childCategoryId}/deep/${deepChildId}`;
    } else {
      url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/child/${childCategoryId}/deep/${deepChildId}`;
    }

    // ✅ FINAL PAYLOAD (AS YOU WANT)
    const payload = {
      documentId: deepChildId,

      // 📝 CONTENT
      firstTitle: data.firstTitle,
      secondTitle: data.secondTitle,
      description: data.description,
      deepCategoryVisible: data.deepCategoryVisible,
      webviewUrl: data.webviewUrl,

      // ⏰🔥 TIME (MISSING THA – YAHI BUG THA)
      minTime: data.minTime ?? null,
      maxTime: data.maxTime ?? null,
      minTimeVisible: data.minTimeVisible,
      maxTimeVisible: data.maxTimeVisible,

      // 💰 PRICING
      originalPrice: data.originalPrice,
      discountType: data.discountType,
      discountValue: data.discountValue,
      gst: data.gst,
      gstType: data.gstType,

      currentPrice: data.currentPrice,
      priceAfterGst: data.priceAfterGst,
      currentPriceVisible: true,

      // 👁️ VISIBILITY
      firstTitleVisible: data.firstTitleVisible,
      secondTitleVisible: data.secondTitleVisible,
      descriptionVisible: data.descriptionVisible,
      webviewUrlVisible: data.webviewUrlVisible,
      originalPriceVisible: data.originalPriceVisible,

      photoVisible: data.photoVisible,
      videoVisible: data.videoVisible,
    };


    console.log("📦 FINAL PAYLOAD:", payload);

    return axios.post(url, payload, {
      headers: {
        Authorization: token ? `Bearer ${token}` : "",
        "x-api-token": "super_secure_token",
        "Content-Type": "application/json",
      },
    });
  };

  // const addSubDeepChildCategory = async (data: any) => {
  //   const token = localStorage.getItem("token");

  //   const {
  //     mainCategoryId,
  //     subCategoryId,
  //     childCategoryId,
  //     deepChildCategoryId,
  //     subDeepKey,
  //   } = data;

  //   if (!mainCategoryId || !childCategoryId || !deepChildCategoryId || !subDeepKey) {
  //     console.error("❌ REQUIRED IDS MISSING", {
  //       mainCategoryId,
  //       childCategoryId,
  //       deepChildCategoryId,
  //       subDeepKey,
  //     });
  //     return;
  //   }

  //   let url = "";

  //   // ✅ WITH SUB CATEGORY
  //   if (subCategoryId) {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/sub/${subCategoryId}/child/${childCategoryId}/deep/${deepChildCategoryId}/sub/${subDeepKey}`;
  //   }
  //   // ✅ WITHOUT SUB CATEGORY
  //   else {
  //     url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/child-key/${childCategoryId}/deep/${deepChildCategoryId}/sub/${subDeepKey}`;
  //   }

  //   console.log("🌐 SUB-DEEP POST URL:", url);
  //   console.log("📦 FINAL DATA GOING TO MONGO:", data);

  //   return axios.post(
  //     url,
  //     {
  //       // 📝 CONTENT
  //       firstTitle: data.firstTitle,
  //       secondTitle: data.secondTitle,
  //       description: data.description,
  //       visible: data.visible,
  //       webviewUrl: data.webviewUrl,

  //       // 💰 RAW PRICING
  //       originalPrice: data.originalPrice,
  //       discountType: data.discountType,
  //       discountValue: data.discountValue,
  //       gst: data.gst,
  //       gstType: data.gstType,

  //       // 🔥 CALCULATED (NO UI FIELD)
  //       priceAfterGst: data.priceAfterGst,   // ✅ ORIGINAL + GST
  //       currentPrice: data.currentPrice,     // ✅ AFTER DISCOUNT
  //       currentPriceVisible: true,

  //       // 👁️ VISIBILITY FLAGS
  //       firstTitleVisible: data.firstTitleVisible,
  //       secondTitleVisible: data.secondTitleVisible,
  //       descriptionVisible: data.descriptionVisible,
  //       webviewUrlVisible: data.webviewUrlVisible,
  //       originalPriceVisible: data.originalPriceVisible,
  //       minTimeVisible: true,
  //       maxTimeVisible: true,

  //       // 📷 MEDIA FLAGS
  //       photoVisible: data.photoVisible,
  //       videoVisible: data.videoVisible,

  //       // 🆔 IDS (IMPORTANT FOR MONGO)
  //       documentId: subDeepKey,
  //       localId: subDeepKey,
  //     },
  //     {
  //       headers: {
  //         Authorization: token ? `Bearer ${token}` : "",
  //         "x-api-token": "super_secure_token",
  //         "Content-Type": "application/json",
  //       },
  //     }
  //   );
  // };

  const addSubDeepChildCategory = async (data: any) => {
    const token = localStorage.getItem("token");

    const {
      mainCategoryId,
      subCategoryId,
      childCategoryId,
      deepChildCategoryId,
      subDeepKey,
    } = data;

    // Check for duplicate
    if (subDeepChildCategories.some(c => (c.id || c.subDeepKey || "").toLowerCase() === subDeepKey.toLowerCase())) {
      alert("Sub Deep Child Category with this name/ID already exists!");
      return;
    }

    let url = "";

    if (subCategoryId) {
      url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/sub/${subCategoryId}/child/${childCategoryId}/deep/${deepChildCategoryId}/sub/${subDeepKey}`;
    } else {
      url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/child/${childCategoryId}/deep/${deepChildCategoryId}/sub/${subDeepKey}`;
    }

    await axios.post(
      url,
      {
        // 📝 CONTENT
        firstTitle: data.firstTitle,
        secondTitle: data.secondTitle,
        description: data.description,
        visible: data.subDeepCategoryVisible ?? data.visible,
        webviewUrl: data.webviewUrl,

        // ⏰🔥 DELIVERY TIME (MAIN FIX)
        minTime: data.minTime ?? null,
        maxTime: data.maxTime ?? null,
        minTimeVisible: data.minTimeVisible,
        maxTimeVisible: data.maxTimeVisible,

        // 💰 PRICING
        originalPrice: data.originalPrice,
        discountType: data.discountType,
        discountValue: data.discountValue,
        gst: data.gst,
        gstType: data.gstType,

        priceAfterGst: data.priceAfterGst,
        currentPrice: data.currentPrice,
        currentPriceVisible: true,

        // 👁️ VISIBILITY
        firstTitleVisible: data.firstTitleVisible,
        secondTitleVisible: data.secondTitleVisible,
        descriptionVisible: data.descriptionVisible,
        webviewUrlVisible: data.webviewUrlVisible,
        originalPriceVisible: data.originalPriceVisible,

        // 📷 MEDIA
        photoVisible: data.photoVisible,
        videoVisible: data.videoVisible,

        // 🆔 IDS
        documentId: subDeepKey,
        // localId: subDeepKey,
      },
      {
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
          "x-api-token": "super_secure_token",
          "Content-Type": "application/json",
        },
      }
    );

    // 🔥 REFRESH LIST
    await fetchSubDeepChildCategories(
      mainCategoryId,
      childCategoryId,
      deepChildCategoryId,
      subCategoryId
    );

  };




  const deleteMainCategory = async (id: string) => {
    try {
      await api.delete(`/main/${id}`);
      setMainCategories((prev) => prev.filter((cat) => (cat._id || (cat as any).id) !== id));
    } catch (e) {
      alert("Failed to delete Main Category");
      console.error(e);
    }
  };

  const deleteSubCategory = async (id: string) => {
    try {
      const sub = subCategories.find(s => (s.documentId || (s as any)._id || (s as any).id) === id);
      if (!sub) {
        // alert("Sub Category not found for deletion.");
        return;
      }
      await api.delete(`/main/${sub.mainCategoryId}/sub/${id}`);
      setSubCategories((prev) => prev.filter((cat) => (cat.documentId || (cat as any)._id || (cat as any).id) !== id));
    } catch (e) {
      alert("Failed to delete Sub Category");
      console.error(e);
    }
  };

  const deleteChildCategory = async (id: string) => {
    try {
      const child = childCategories.find(c => (c.documentId || (c as any)._id || (c as any).id) === id);
      if (!child) return;

      // Try to find sub - if not found, it might be a direct child of main? 
      // Current context assumes hierarchical structure for deletion, need to be careful.
      // For now, finding sub is safest if we follow the full path.
      // If we don't have subId, maybe we can delete directly if backend supports it or if we stored parentId.

      const sub = subCategories.find(s => (s.documentId || (s as any)._id || (s as any).id) === child.subCategoryId);
      // NOTE: strict dependency on sub might be issue if we navigated directly. 
      // But for now, let's assume we have it or modify backend to simple delete.

      if (sub) {
        await api.delete(`/main/${sub.mainCategoryId}/sub/${sub.documentId}/child/${id}`);
      } else {
        // Fallback: maybe direct child of main? user needs to fix this if architecture supports it
        console.warn("Parent SubCategory not found for deletion, trying direct?");
        // await api.delete(...) // Risk.
      }

      setChildCategories((prev) => prev.filter((cat) => (cat.documentId || (cat as any)._id || (cat as any).id) !== id));
    } catch (e) {
      alert("Failed to delete Child Category");
      console.error(e);
    }
  };

  const deleteDeepChildCategory = async (id: string) => {
    try {
      const deep = deepChildCategories.find(d => (d.id || (d as any)._id || (d as any).documentId) === id);
      if (!deep) return;

      setDeepChildCategories((prev) => prev.filter((cat) => (cat.id || (cat as any)._id || (cat as any).documentId) !== id));
      // Add API call if needed
    } catch (e) {
      console.error(e);
    }
  };

  // SubDeepChildCategory deletion (local only)
  const deleteSubDeepChildCategory = (id: string) => {
    setSubDeepChildCategories((prev) => prev.filter((cat) => (cat.id || (cat as any)._id) !== id));
  };

  // TOGGLE VISIBILITY
  // const toggleMainVisibility = async (id: string) => {
  //   const cat = mainCategories.find(c => c._id === id);
  //   if (!cat) return;

  //   // Toggle
  //   const newVal = !cat.isMainCategoryVisible;
  //   // We use isMainCategoryVisible based on interface, but previously used visible. 
  //   // Let's normalize update.

  //   const updated = { ...cat, isMainCategoryVisible: newVal, visible: newVal };

  //   // Optimistic update
  //   setMainCategories(prev => prev.map(c => c._id === id ? updated : c));
  //   try {
  //     await api.put(`/main/${id}`, updated);
  //   } catch (e) {
  //     console.error("Failed to toggle main visibility", e);
  //     // Revert on failure
  //     setMainCategories(prev => prev.map(c => c._id === id ? cat : c));
  //     alert("Failed to update visibility");
  //   }
  // };
  const toggleMainVisibility = async (id: string) => {
    const cat = mainCategories.find(c => c._id === id);
    if (!cat) return;

    const newVal = !cat.isMainCategoryVisible;

    // ✅ Optimistic UI
    setMainCategories(prev =>
      prev.map(c =>
        c._id === id ? { ...c, isMainCategoryVisible: newVal } : c
      )
    );

    try {
      const token = localStorage.getItem("token");

      await axios.put(
        `https://api.bijliwalaaya.in/api/product-listing/main/${id}`,
        { isMainCategoryVisible: newVal }, // 🔥 ONLY THIS FIELD
        {
          headers: {
            "Content-Type": "application/json",
            "x-api-token": "super_secure_token",
            Authorization: token ? `Bearer ${token}` : "",
          },
        }
      );
    } catch (err) {
      console.error("❌ toggleMainVisibility failed", err);

      // 🔁 revert UI
      setMainCategories(prev =>
        prev.map(c => (c._id === id ? cat : c))
      );
    }
  };

  const toggleMainNameVisibility = async (id: string) => {
    const cat = mainCategories.find(c => c._id === id);
    if (!cat) return;

    const newVal = !cat.isMainCategoryNameVisible;

    // ✅ Optimistic UI
    setMainCategories(prev =>
      prev.map(c =>
        c._id === id ? { ...c, isMainCategoryNameVisible: newVal } : c
      )
    );

    try {
      const token = localStorage.getItem("token");

      const payload = {
        name: cat.name,
        imageUri: cat.imageUri || null,

        isMainCategoryVisible: cat.isMainCategoryVisible,
        isMainCategoryNameVisible: newVal,          // 🔥 ONLY CHANGE
        isMainCategoryImageVisible: cat.isMainCategoryImageVisible,

        hasSubCategory: cat.hasSubCategory,
        parentId: cat.parentId || null,
      };

      await axios.put(
        `https://api.bijliwalaaya.in/api/product-listing/main/${id}`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
            "x-api-token": "super_secure_token",
            Authorization: token ? `Bearer ${token}` : "",
          },
        }
      );
    } catch (err) {
      console.error("❌ toggleMainNameVisibility failed", err);

      // 🔁 revert UI
      setMainCategories(prev =>
        prev.map(c => (c._id === id ? cat : c))
      );
    }
  };



  const toggleMainIsSub = async (id: string) => {
    const cat = mainCategories.find(c => c._id === id);
    if (!cat) return;
    const updated = { ...cat, hasSubCategory: !cat.hasSubCategory };
    setMainCategories(prev => prev.map(c => c._id === id ? updated : c));
    try {
      await api.put(`/main/${id}`, updated);
    } catch (e) {
      console.error("Failed to toggle isSubCategory", e);
      setMainCategories(prev => prev.map(c => c._id === id ? cat : c));
      alert("Failed to update");
    }
  };

  const toggleMainImageVisibility = async (id: string) => {
    const cat = mainCategories.find(c => c._id === id);
    if (!cat) return;

    const newVal = !cat.isMainCategoryImageVisible;
    const updated = {
      ...cat,
      isMainCategoryImageVisible: newVal
    };

    setMainCategories(prev => prev.map(c => c._id === id ? updated : c));

    try {
      await api.put(`/main/${id}`, updated);
    } catch (e) {
      console.error("Failed to toggle main image visibility", e);
      setMainCategories(prev => prev.map(c => c._id === id ? cat : c));
    }
  };

  const toggleSubVisibility = async (id: string) => {
    const cat = subCategories.find(c => (c.documentId || (c as any)._id) === id);
    if (!cat) return;

    // Toggle
    const newVal = !cat.isSubCategoryVisible;
    const updated = {
      ...cat,
      visible: newVal,
      isSubCategoryVisible: newVal
    };

    // Optimistic Update
    setSubCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? updated : c));

    try {
      // ✅ Construct Clean Payload matching addSubCategory structure
      const payload = {
        name: cat.name,
        mainCategory: cat.mainCategoryId, // Ensure this matches addSubCategory param
        isSubCategoryVisible: newVal,
        isSubCategoryNameVisible: cat.isSubCategoryNameVisible ?? true, // Pass this to maintain state
        isSubCategoryImageVisible: cat.isSubCategoryImageVisible,
        hasSubCategory: cat.hasSubCategory,
        imageUri: cat.imageUri || null,
        // visible: newVal // If backend needs alias
      };

      console.log("🚀 Toggle Sub Visibility Payload:", payload);

      await api.put(`/main/${cat.mainCategoryId}/sub/${id}`, payload);
    } catch (e) {
      console.error("Failed to toggle sub visibility", e);
      // Revert
      setSubCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? cat : c));
    }
  };

  // const toggleSubNameVisibility = async (id: string) => {
  //   const cat = subCategories.find(c => (c.documentId || (c as any)._id) === id);
  //   if (!cat) return;

  //   const newVal = !cat.isSubCategoryNameVisible;
  //   const updated = {
  //     ...cat,
  //     isSubCategoryNameVisible: newVal
  //   };

  //   setSubCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? updated : c));

  //   try {
  //     // ✅ Construct Clean Payload matching addSubCategory structure
  //     const payload = {
  //       name: cat.name,
  //       mainCategory: cat.mainCategoryId, // Ensure this matches addSubCategory param
  //       isSubCategoryVisible: newVal, // ✅ Sync with Name Visibility
  //       isSubCategoryNameVisible: newVal, // ✅ Toggle this
  //       isSubCategoryImageVisible: cat.isSubCategoryImageVisible,
  //       hasSubCategory: cat.hasSubCategory,
  //       imageUri: cat.imageUri || null,
  //     };

  //     console.log("🚀 Toggle Sub Name Visibility Payload:", payload);

  //     await api.put(`/main/${cat.mainCategoryId}/sub/${id}`, payload);
  //   } catch (e) {
  //     console.error("Failed to toggle sub name visibility", e);
  //     // Revert
  //     setSubCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? cat : c));
  //   }
  // };
  const toggleSubNameVisibility = async (id: string) => {
    const cat = subCategories.find(c => c.documentId === id);
    if (!cat) return;

    const newVal = !cat.isSubCategoryNameVisible;

    const updated = {
      ...cat,
      isSubCategoryNameVisible: newVal
    };

    // Optimistic UI
    setSubCategories(prev =>
      prev.map(c => c.documentId === id ? updated : c)
    );

    try {
      const payload = {
        name: cat.name,
        mainCategory: cat.mainCategoryId,

        // 🔒 KEEP EXISTING VALUES
        isSubCategoryVisible: cat.isSubCategoryVisible,
        isSubCategoryNameVisible: newVal,
        isSubCategoryImageVisible: cat.isSubCategoryImageVisible,

        hasSubCategory: cat.hasSubCategory,
        imageUri: cat.imageUri || null,
      };

      await api.put(`/main/${cat.mainCategoryId}/sub/${id}`, payload);
    } catch (e) {
      setSubCategories(prev =>
        prev.map(c => c.documentId === id ? cat : c)
      );
    }
  };

  const toggleSubImageVisibility = async (id: string) => {
    const cat = subCategories.find(c => (c.documentId || (c as any)._id) === id);
    if (!cat) return;

    const newVal = !cat.isSubCategoryImageVisible;
    const updated = {
      ...cat,
      isSubCategoryImageVisible: newVal
    };

    setSubCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? updated : c));

    try {
      // ✅ Construct Clean Payload
      const payload = {
        name: cat.name,
        mainCategory: cat.mainCategoryId,
        isSubCategoryVisible: cat.isSubCategoryVisible, // Keep existing
        isSubCategoryNameVisible: cat.isSubCategoryNameVisible ?? true, // Maintain state
        isSubCategoryImageVisible: newVal,              // ✅ Toggle this
        hasSubCategory: cat.hasSubCategory,
        imageUri: cat.imageUri || null,
      };

      console.log("🚀 Toggle Sub Image Visibility Payload:", payload);

      await api.put(`/main/${cat.mainCategoryId}/sub/${id}`, payload);
    } catch (e) {
      console.error("Failed to toggle sub image visibility", e);
      setSubCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? cat : c));
    }
  };

  const toggleSubHasSubCategory = async (id: string) => {
    const cat = subCategories.find(c => (c.documentId || (c as any)._id) === id);
    if (!cat) return;

    const newVal = !cat.hasSubCategory;
    const updated = {
      ...cat,
      hasSubCategory: newVal
    };

    setSubCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? updated : c));

    try {
      // ✅ Construct Clean Payload
      const payload = {
        name: cat.name,
        mainCategory: cat.mainCategoryId,
        isSubCategoryVisible: cat.isSubCategoryVisible,
        isSubCategoryNameVisible: cat.isSubCategoryNameVisible ?? true, // Maintain state
        isSubCategoryImageVisible: cat.isSubCategoryImageVisible,
        hasSubCategory: newVal, // ✅ Toggle this
        imageUri: cat.imageUri || null,
      };

      console.log("🚀 Toggle Sub Has SubCategory Payload:", payload);

      await api.put(`/main/${cat.mainCategoryId}/sub/${id}`, payload);
    } catch (e) {
      console.error("Failed to toggle sub hasSubCategory", e);
      setSubCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? cat : c));
    }
  };

  const toggleChildVisibility = async (id: string) => {
    const cat = childCategories.find(c => (c.documentId || (c as any)._id) === id);
    if (!cat) return;

    // ✅ CRITICAL FIX: Correctly resolve current visibility
    // If we only check .visible and it's undefined, it defaults to false, so toggle makes it true. 
    // If it's undefined but 'visibility' is true, we falsely think it's false and toggle to true (staying true).
    const currentVisibility = (cat as any).visible ?? (cat as any).visibility ?? (cat as any).Visibility ?? false;
    const newVal = !currentVisibility;

    // Create updated object for local state (update BOTH keys to be safe)
    const updatedLocal = {
      ...cat,
      visible: newVal,
      visibility: newVal
    };

    // Optimistically update local state
    setChildCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? updatedLocal : c));

    try {
      const sub = subCategories.find(s => (s.documentId || (s as any)._id) === cat.subCategoryId);

      let url = "";
      if (sub) {
        url = `/main/${sub.mainCategoryId}/sub/${sub.documentId}/child/${id}`;
      } else {
        const main = mainCategories.find(m => (m._id || (m as any).id) === (cat as any).mainCategoryId);
        if (main) {
          url = `/main/${main._id}/child/${id}`;
        }
      }

      if (url) {
        // Send ALL variations to ensure backend updates the right one
        const payload = {
          ...cat,
          visible: newVal,
          visibility: newVal, // ✅ Lowercase 'visibility' matches your DB screenshot
          Visibility: newVal,
          isChildCategoryVisible: newVal
        };

        console.log("🚀 Toggling Child Visibility:", url, payload);
        await api.put(url, payload);
      } else {
        console.warn("Could not determine parent path for child category toggle");
      }

    } catch (e) {
      console.error("Failed to toggle child visibility", e);
      // Revert on failure
      setChildCategories(prev => prev.map(c => (c.documentId || (c as any)._id) === id ? cat : c));
      alert("Failed to update visibility");
    }
  };

  const toggleDeepChildVisibility = async (id: string, field: string = "visible") => {
    const cat = deepChildCategories.find(c => (c.id || (c as any).documentId) === id);
    if (!cat) return;

    // Determine current value safety
    const currentVal = (cat as any)[field] ?? false;
    const newVal = !currentVal;

    const updated = { ...cat, [field]: newVal };

    // Toggle main visibility alias if needed
    if (field === "deepCategoryVisible") {
      updated.visible = newVal;
    }

    setDeepChildCategories(prev => prev.map(c => (c.id || (c as any).documentId) === id ? updated : c));

    // Optimistic UI
    setDeepChildCategories(prev => prev.map(c => (c.id || (c as any).documentId) === id ? updated : c));

    try {
      const token = localStorage.getItem("token");
      const mainCategoryId = cat.mainCategoryId;
      const childCategoryId = cat.childCategoryId;
      const subCategoryId = cat.subCategoryId;

      // Ensure specific ID is used for URL
      const deepId = cat.id || (cat as any).documentId;

      if (!mainCategoryId || !childCategoryId) {
        console.error("Missing parent IDs for deep child update", cat);
        return;
      }

      let url = "";
      if (subCategoryId) {
        url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/sub/${subCategoryId}/child/${childCategoryId}/deep/${deepId}`;
      } else {
        url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/child/${childCategoryId}/deep/${deepId}`;
      }

      console.log(`🚀 Updating Deep Child Field [${field}] to [${newVal}]`, url);

      await axios.put(url, updated, {
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
          "x-api-token": "super_secure_token",
          "Content-Type": "application/json",
        }
      });

    } catch (e: any) {
      console.error("Failed to update deep child category", e.response?.data || e);
      // Revert if needed, or just alert
      // setDeepChildCategories(prev => prev.map(c => (c.id || (c as any).documentId) === id ? cat : c));
    }
  };

  const toggleSubDeepChildVisibility = async (id: string, field: string = "visible") => {

    // Find item
    const cat = subDeepChildCategories.find((cat) => (cat.id || (cat as any).subDeepKey || (cat as any).documentId) === id);
    if (!cat) return;

    // Determine values
    const currentVal = (cat as any)[field] ?? false;
    const newVal = !currentVal;

    const updated = { ...cat, [field]: newVal };
    if (field === "subDeepCategoryVisible") {
      updated.visible = newVal;
    }

    // Optimistic Update
    setSubDeepChildCategories((prev) =>
      prev.map((c) => (c.id === id || (c as any).subDeepKey === id) ? updated : c)
    );

    // Persist to Backend
    try {
      const token = localStorage.getItem("token");
      const { mainCategoryId, subCategoryId, childCategoryId, deepChildCategoryId, subDeepKey, documentId } = cat;
      const subDeepId = subDeepKey || documentId || id;

      if (!mainCategoryId || !childCategoryId || !deepChildCategoryId) {
        console.error("Missing parent context for sub-deep update", cat);
        return;
      }

      let url = "";

      if (subCategoryId) {
        url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/sub/${subCategoryId}/child/${childCategoryId}/deep/${deepChildCategoryId}/sub/${subDeepId}`;
      } else {
        url = `https://api.bijliwalaaya.in/api/product-listing/main/${mainCategoryId}/child/${childCategoryId}/deep/${deepChildCategoryId}/sub/${subDeepId}`;
      }

      console.log(`🚀 Updating Sub-Deep Field [${field}] to [${newVal}]`, url);

      await axios.put(url, updated, {
        headers: {
          Authorization: token ? `Bearer ${token}` : "",
          "x-api-token": "super_secure_token",
          "Content-Type": "application/json",
        }
      });
    } catch (e: any) {
      console.error("Failed to update sub-deep child category", e.response?.data || e);
    }
  };

  return (
    <CategoryContext.Provider
      value={{
        mainCategories,
        subCategories,
        childCategories,
        deepChildCategories,
        subDeepChildCategories, // Ensure this is here
        addMainCategory: addMainCategory as any,
        fetchMainCategories,
        addSubCategory: addSubCategory as any,
        addChildCategory: addChildCategory as any,
        addDeepChildCategory: addDeepChildCategory as any,
        fetchSubDeepChildCategories, // Add this missing one
        addSubDeepChildCategory, // Ensure this is here
        deleteMainCategory,
        deleteSubCategory,
        deleteChildCategory,
        deleteDeepChildCategory,
        deleteSubDeepChildCategory, // Ensure this is here
        toggleMainVisibility,
        toggleMainNameVisibility,
        toggleMainImageVisibility,
        toggleMainIsSub,   // ✅ only once
        toggleSubVisibility,
        toggleSubNameVisibility, // ✅ Expose this function
        toggleSubImageVisibility,
        toggleSubHasSubCategory,
        toggleChildVisibility,
        toggleDeepChildVisibility,
        toggleSubDeepChildVisibility,
        isLoadingSubDeep,
        fetchSubCategories,
        updateMainCategory,
        updateSubCategory,
        updateChildCategory,
        updateChildCategoryWithSub,
        updateDeepChildCategory,
        updateDeepChildCategoryWithSub,
        updateSubDeepChildCategory,
        fetchChildCategories,
        fetchDeepChildCategories
      }}
    >
      {children}
    </CategoryContext.Provider>
  );
};

export const useCategory = () => {
  const context = useContext(CategoryContext);
  if (!context) {
    throw new Error('useCategory must be used within a CategoryProvider');
  }
  return context;
};
