"use client";

import InventoryDashboard from "./components/InventoryDashboard";

export default function Home() {
  return (
    <InventoryDashboard />
  );
}
