"use client";

import InventoryDashboard from "../components/InventoryDashboard";

export default function InventoryManagement() {
    return <InventoryDashboard />;
}
