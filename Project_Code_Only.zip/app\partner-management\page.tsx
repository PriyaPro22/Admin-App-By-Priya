"use client";

import PlaceholderPage from "../components/PlaceholderPage";

export default function PartnerManagement() {
    return <PlaceholderPage title="Partner Management" />;
}
